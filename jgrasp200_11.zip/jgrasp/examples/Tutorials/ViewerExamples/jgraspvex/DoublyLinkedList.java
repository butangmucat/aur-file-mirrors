package jgraspvex;


public class DoublyLinkedList {
 
   private int size; 

   private DoublyLinkedNode head;
   
   private DoublyLinkedNode last;


   public DoublyLinkedList() {
   }


   public void add(Object value) {
      DoublyLinkedNode node = new DoublyLinkedNode(value);
      if (head != null) {
         node.prev = head.prev;
         node.next = head;
         head.prev = node;
         last.next = node;
      }
      else {
         node.next = node;
         node.prev = node;
         last = node;
      }
      head = node;
      size++;
   }


   public void insert(Object value, int index) {
      if (index == 0) {
         add(value);
         return;
      }
      DoublyLinkedNode node = new DoublyLinkedNode(value);
   
      DoublyLinkedNode prev = head;
      for (int i = 1; i < index; i++) {
         prev = prev.next;
      }
      node.next = prev.next;
      node.prev = prev;
      node.next.prev = node;
      if (last == prev) {
         last = node;
      }
      prev.next = node;
      
      size++;
   }
   

   public Object remove(int index) {
      if (index == 0) {
         Object result = head;
         head = head.next;
         if (head == result) {
            head = null;
            last = null;
         }
         else {
            head.prev = last;
            last.next = head;
         }
         size--;
         return head;
      }
    
      DoublyLinkedNode prev = head;
      for (int i = 1; i < index; i++) {
         prev = prev.next;
      }
      Object result = prev.next;
      prev.next = prev.next.next;
      if (prev.next == last) {
         last = prev;
      }
      if (prev.next != null) {
         prev.next.prev = prev;
      }
      size--;
      return result;
   }
   
   
   public int size() {
      return size;
   }


   public Object get(int index) {
      DoublyLinkedNode node = head;
      for (int i = 0; i < index; i++) {
         node = node.next;
      }
      return node.value;
   }
}

