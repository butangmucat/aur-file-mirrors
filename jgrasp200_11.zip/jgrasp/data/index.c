s
compiler environments
DJGPP2
 !A:  +I  3$   ?
Sun cc - Solaris
  @V  +F  .N  !!
gcc - generic - OpenGL
  OD  ,R  0<  !I
Borland BCC 5.5 - Windows
      ,#  1V  "4
gcc - generic - Insight debugger
 !/Z  ,'  1@  #&
Microsoft Visual Studio (or Express)
 !T>  />  =H  #\
gcc - generic
  1V  ,6  /   $;
cc (gcc) - Mac OS X
 !    +   /Z  % 
