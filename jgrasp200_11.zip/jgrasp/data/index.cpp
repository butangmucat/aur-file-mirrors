s
compiler environments
g++ - generic - OpenGL
  O<  -#  0Z   O
DJGPP2
 !CR  +Z  3$  !'
g++ - generic
  0F  ,G  /J  !F
Borland BCC 5.5 - Windows
      +X  0F  "1
c++ (g++) - Mac OS X
 ! 6  +4  0^  "W
Sun CC - Solaris
  @0  +S  /,  #9
Microsoft Visual Studio (or Express)
 !VV  /O  6B  $/
g++ - generic - Insight debugger
 !14  ,D  2>  %!
