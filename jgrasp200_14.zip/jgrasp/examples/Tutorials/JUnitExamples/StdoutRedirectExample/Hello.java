/** Simple program with output to System.out.  */
public class Hello {
   /**
    * Main method for driver for class Triangle.
    *
    * @param args - Standard commandline arguments
    */
   public static void main(String[] args) {  
      System.out.println("Printing to stdout");
      System.out.println("Hello 1"); 
      System.out.println("Hello 2");
      System.out.println("Hello 3"); 
      System.out.println("Hello 4");  
   } 
}