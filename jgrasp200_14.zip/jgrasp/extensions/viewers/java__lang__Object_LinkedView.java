
   import jgrasp.viewer.ViewerCreateData;
   
   import jgrasp.viewer.presentation.GenericLinkedView;


   /** The structure identifier viewer. **/
    public class java__lang__Object_LinkedView extends GenericLinkedView {
   
   
      /** Creates a new structure identifier viewer.
       *
       *  @param vcd creation data. **/
       public java__lang__Object_LinkedView(final ViewerCreateData vcd) {
      }
   }
