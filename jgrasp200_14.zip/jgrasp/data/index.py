s
compiler environments
Python 3 - generic
      %T  (    K
Python 2 - generic
  (   %T  *2  !/
