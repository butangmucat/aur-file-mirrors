s
compiler environments
Microsoft Visual Studio (or Express)
 !E\  /O  6B   ]
c++ (g++) - Mac OS X
  O<  +4  0^  !C
g++ - generic
  0F  ,G  /J  ""
DJGPP2
 !2X  +Z  3$  ":
Borland BCC 5.5 - Windows
      +X  0F  #%
Sun CC - Solaris
  @0  +S  /,  #G
g++ - MinGW - OpenGL32 with freeglut
 "6^  -)  :X  $=
g++ - generic - Insight debugger
 ! :  ,D  2>  %/
g++ - generic - OpenGL with GLUT
 !\>  -0  :@  &!
